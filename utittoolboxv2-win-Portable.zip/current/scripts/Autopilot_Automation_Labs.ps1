$tag=$($args[0])

if ($args.Count -lt 1) {
     Write-Host "To Run the Autopilot_Automation.ps1 you will need an argument passed in:" -ForegroundColor Cyan
     Write-Host "1. GroupTag for intune (i.e STAFF-ITS)" -ForegroundColor Green
     Write-Host "   - For more information reguarding what GroupTag to use please reach out to Skyler or Shawn P." -ForegroundColor Green
    exit
}

Write-Host "Starting Autopilot_Automation.ps1" -ForegroundColor Cyan
Write-Host "GroupTag: $tag" -ForegroundColor Yellow
Write-Host ""

Write-Host "Installing NuGet" -ForegroundColor Cyan
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Write-Host "Install Complete" -ForegroundColor Green
Write-Host ""

Write-Host "Installing Get-WindowsAutoPilotInfo" -ForegroundColor Cyan
install-script get-windowsautopilotinfo -Force
Write-Host "Install Complete" -ForegroundColor Green
Write-Host ""

Write-Host "Running Get-WindowsAutoPilotInfo" -ForegroundColor Cyan
get-windowsautopilotinfo -Online -GroupTag $tag -TenantID b7ae04ec-605a-4bd7-9fca-3ef0bc7e8ac6 -AppId 50b790d3-66db-4718-bfa2-efec85b1bad7 -AppSecret Hd88Q~aLdIoZRCniaeoGbq4QeIWiRbMxZLzlWddu
Write-Host "Done" -ForegroundColor Green

pause