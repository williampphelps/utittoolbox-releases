TO BACKUP USER

Run CopyUser.bat as administrator
Enter D# (i.e D00000000)
Enter Location to store the profile (example: D:\Users\First Last 6-3-23 or \\servername\pathhere)


TO REPLACE USER



Run PasteUser.bat as administrator
Enter D# (i.e D00000000)
Enter Location to store the profile (example: D:\Users\First Last 6-3-23 or \\servername\pathhere)