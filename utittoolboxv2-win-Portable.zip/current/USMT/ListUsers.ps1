﻿$profiles = Get-WmiObject -Class Win32_UserProfile | Where-Object { $_.Special -ne $true -and $_.RoamingConfigured -eq $false }
foreach ($profile in $profiles) {
    $user = [System.Security.Principal.SecurityIdentifier]::new($profile.SID)
    
    # Check if the account is Azure AD joined
    $azureADJoined = $false
    try {
        $adObject = Get-AzureADUser -ObjectId $user.Value
        if ($adObject) {
            $azureADJoined = $true
        }
    } catch {
        # Handle error if the user is not found in Azure AD
        $azureADJoined = $false
    }
    
    # Check if the profile should be excluded based on domain prefix
    if ($azureADJoined) {
        # Get the domain name for Azure AD joined accounts
        $domain = $adObject.UserPrincipalName.Split("@")[1]
        $username = $adObject.UserPrincipalName.Split("@")[0]
    } else {
        # Get the domain\username format for non-Azure AD joined accounts
        $account = $user.Translate([System.Security.Principal.NTAccount]).Value
        if ($account -match "^(?<domain>.+)\\(?<username>.+)$") {
            $domain = $matches['domain']
            $username = $matches['username']
        } else {
            # If unable to match the domain\username format, fallback to SID
            $username = $user.Value
        }
    }
    
    # Exclude profiles with domain prefix "MEM\"
    if ($domain -ne "MEM") {
        Write-Output "$domain\$username"
    }
}
